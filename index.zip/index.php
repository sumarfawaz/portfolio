


<?php 

include 'conn.php';
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  if ($_POST["inputFirstName"]=="/,*,$,^,#" || $_POST["inputLastName"]=="/,*,$,^,#" || $_POST["inputEmail"] == "/,*,$,^,#" || $_POST["message"]=="/,*,$,^,#" || $_POST["countryCode"]=="/,*,$,^,#" || $_POST["mobilenumber"]=="/,*,$,^,#")  {
    $spcerr = "You cannot use special characters!";
  }
}
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Vaceyra</title>
    <link rel="stylesheet" href="/assets/css/style.css">
    <link rel="stylesheet" href="/assets/css/fontawesome.css">
    <link href="https://fonts.googleapis.com/css2?family=Fascinate&family=Kdam+Thmor+Pro&family=Montserrat:ital,wght@0,900;1,900&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;1,100;1,200;1,300;1,400;1,500;1,600&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat+Alternates:wght@300&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poiret+One&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Edu+VIC+WA+NT+Beginner&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100&display=swap" rel="stylesheet"
    <link rel="stylesheet" href="/assets/vendors/css/glightbox.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.js"></script>
    <link rel="icon" href="favicon.ico" type="image/x-icon">

<!--STYLING THE SCROLLBAR-->
    <style>

      ::-webkit-scrollbar{
        width: 10px;

      }
      ::-webkit-scrollbar-track{
        border-radius: 5px;
        box-shadow: inset 0 0 10px #f0e9e9;

      }
      ::-webkit-scrollbar-thumb{
        border-radius: 5px;
        background-color: #eb0202;
        
      }
      ::-webkit-scrollbar-thumb:hover{
        background-color: #2F303A;
      }

    </style>
<!--STYLING THE SCROLLBAR-->
  </head>
<body>

    <!--NAVBAR-->
    <nav class="navbar navbar-expand-lg navbar-dark menu shadow fixed-top" id="nau">
        <div class="container">
          <a class="navbar-brand " href="#"><img src="/images/logoorg.png" alt="logoorg" style="height: 75px;"></a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
            <ul class="navbar-nav">
              <li class="nav-item ">
                <a class="nav-link active" aria-current="page" href="index.html">Home</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="services.html">Services</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="pricing.html">Pricing</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#faq">FAQ</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#contact">Contact</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="/pricing.html#aboutus">About Us</a>
              </li>
            </ul>
            <!--<button type="button" class="rounded-pill btn-rounded">vaceyra@gmail.com
                <span><i class="fa-regular fa-envelope"></i></span>
            </button>-->
          </div>
        </div>
      </nav>
      <!--NAVBAR ENDS-->

      <!--INTRO SECTION START-->
      <section id="home" class="intro-section">
        <div class="container">
            <div class="row align-items-center text-white">
              <!--heading and intro goes here-->     
              <div class="col-md-6 intros">
                        <h1 class=" display-3">
                            <span class="display-2--intro">Vaceyra welcomes you!</span>
                            <span class="display-2--description lh-base"> “Wants to Needs” <br> Awareness, sales, and information make businesses grow faster. Make your business appear on the biggest network created by mankind. Vaceyra will build your dream website. 
                           </span>
                        </h1>
                        <br>
                        <br>
                       <a href="#contact">
                        <button type="button" class="rounded-pill btn-rounded">Get Started
                          <span><i class="fas fa-arrow-right"></i></span>
                      </button>
                       </a>
                    </div>
                    <!--Illustration goes here-->
                <div class="col-md-6 intros text-end">
                 <div class="illustration-box">
                    <img src="/images/arts/World wide web_Flatline.png" alt="illustration" class="img-fluid">
                  </div>
                </div>
            </div>
        </div>
        <br>
        <br><br>
        <br>
        <br>
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320"><path fill="#ffffff" fill-opacity="1" d="M0,320L24,298.7C48,277,96,235,144,181.3C192,128,240,64,288,80C336,96,384,192,432,208C480,224,528,160,576,122.7C624,85,672,75,720,90.7C768,107,816,149,864,186.7C912,224,960,256,1008,266.7C1056,277,1104,267,1152,234.7C1200,203,1248,149,1296,117.3C1344,85,1392,75,1416,69.3L1440,64L1440,320L1416,320C1392,320,1344,320,1296,320C1248,320,1200,320,1152,320C1104,320,1056,320,1008,320C960,320,912,320,864,320C816,320,768,320,720,320C672,320,624,320,576,320C528,320,480,320,432,320C384,320,336,320,288,320C240,320,192,320,144,320C96,320,48,320,24,320L0,320Z"></path></svg>
      </section>
      <!--INTRO SECTION END-->
      <br>
      <br>
      <!--LOGO SLIDER START-->
      <div class="container-fluid">
        <!--<h2>Our  Partners</h2>-->
         <section class="customer-logos slider ">
            <div class="slide "><img src="/images/logoorg.png"></div>
            <div class="slide "><img src="/images/logoorg.png"></div>
            <div class="slide "><img src="/images/logoorg.png"></div>
            <div class="slide "><img src="/images/logoorg.png"></div>
            <div class="slide "><img src="/images/logoorg.png"></div>
            <div class="slide "><img src="/images/logoorg.png"></div>
            <div class="slide "><img src="/images/logoorg.png"></div>
         </section>
      </div>
      <!--LOGO SLIDER END-->
        <br>
        <br>
      <!--SERVICES START-->
            <section id="services" class="services">
                <div class="container">
                    <div class="row text-center">
                        <h1 class="display-3 fw-bold">Services</h1>
                        <div class="heading-line mb-3"></div>
                    </div>
                </div>

                <!--DESCRIPTION OF THE CONTENT-->
                <div class="container">
                  <div class="row md-pt-2 md-pb-2 md-mt-5 md-mb-3">
                    <div class="col-md-6 border-right"  >
                      <div class="bg-white md-p-5">
                        <h2 class="fw-bold  text-center ">
                          "Websites For Everyone!."
                         <span>Our vision is to make websites affordable 
                          to the majority and our services will get us there.</span> 
                        </h2>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="bg-white md-p-5 sm-p-2 md-pt-2 text-start text-justify">
                        <br>
                        <p class="fw-light text-bold  "  style="text-align: justify;font-weight: 700; font-size: 1.2rem;">
                          Websites aren’t expensive anymore! Every time you thought of getting yourself a website, it was quite expensive. Get your dream website at a price you never imagined. Websites will give you a digital identity on the internet.  Although websites are a great complication, we will simplify
                           them to your understanding and get your website functional 24/7.
                        </p>
                       <!--<img src="/images/Services/Customer service_Isometric.png" class=" displayonlyinmobile img-fluid"  alt="Services">--> 
                      </div>
                    </div>
                  </div>
                </div>
                <div class="container">
                  <!--section 1__Website Development-->
                  <div class="row">
                    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 services md-mt-4">
                      <div class="services__contents">
                       <div class="icon fas fa-code"></div>
                       <h3 class=" display-3 servicesheading mt-1 ">Website Development</h3>
                       <p class="lh-lg desc" style="font-family: sans-serif;text-align: justify;font-weight: 600;">
                        <b>
                      We have different types of websites that are based on different requirements and needs.
                      Although you have a picture of what your website should look like, you should also choose the correct type of website to accomplish your goals. We will walk you through different types of websites that are widely used by businesses and individuals.  
                    </b>   
                    </p>
                       <img src="/images/Services/HTML_Monochromatic.png" class="displayonlyinmobile img-fluid"  alt="web development">

                       <a href="services.html">
                        <button type="button" class="rounded-pill btn-services border-primary">Go to Services
                          <span><i class="fas fa-arrow-right"></i></span>
                      </button>
                       </a>
                       </div>
                      </div>
                      <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 services md-mt-4 text-end">
                        <div class="services__pic">
                          <img src="/images/Services/HTML_Monochromatic.png" class="img-fluid justify-content-center d-block" id="webillustration" alt="website development">
                        </div>
                      </div>
                    </div>
                    

                    <!--section2__hosting and domains-->
                    <div class="row">
                      <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 services md-mt-4 text-start">
                        <div class="services__pic">
                          <img src="/images/Services/Data Hosting_Outline.png" class="img-fluid justify-content-center d-block" alt="website development">
                        </div>
                      </div>
                      <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 services md-mt-4">
                        <div class="services__contents"><div class="icon fas fa-upload"></div>
                        <h3 class="display-3 servicesheading mt-1 ">Domain and Hosting</h3>
                        <p class="lh-lg desc" style="font-family: sans-serif; text-align:justify;font-weight: 600;">
                         <b> Domain and Hosting are considered the most important procedure in web development. 
                          The domain is a string recognition to your website instead of an IP address which is too long to remember. Hosting is the process of getting your website loaded into a server that runs 24/7. We will do the needful to get you a domain and load your website into a server.  
                        </b>
                        </p>
                        <img src="/images/Services/Data Hosting_Outline.png" class="displayonlyinmobile img-fluid pb-4"  alt="web development">
                        <a href="services.html">
                          <button type="button" class="rounded-pill btn-services border-primary">Go to Services
                            <span><i class="fas fa-arrow-right"></i></span>
                        </button>
                         </a>
                      </div>
                    </div>

                      <!--section3__maintenance and SEO-->
                      <div class="row">
                        <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 services md-mt-4">
                          <div class="services__contents">
                            <div class="icon"><i class="fa-solid fa-screwdriver-wrench"></i></div>
                       <h3 class="display-3 servicesheading mt-1 ">24/7 Maintenance</h3>
                       <p class="lh-lg desc" style="font-family: sans-serif; text-align:justify;font-weight: 600;">
                        <b>
                        We will provide you a template of your 
                        website sectioned by numbers so that 
                        whenever you want to make changes or 
                        update your website, mention the section 
                        and the change 
                        you want to make. Websites crash into
                        different bugs more often; we will get
                        your website loaded into trustworthy 
                        servers that are active to defend 
                        against vulnerabilities. Our team will
                        take care of your privacy and data.</b>
                       </p>
                       <img src="/images/Services/Settings_Monochromatic.png" class="displayonlyinmobile img-fluid pb-4"  alt="web development">
                       <a href="services.html">
                        <button type="button" class="rounded-pill btn-services border-primary">Go to Services
                          <span><i class="fas fa-arrow-right"></i></span>
                      </button>
                       </a>
                          </div>
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 services md-mt-4 text-end ">
                          <div class="services__pic">
                            <img src="/images/Services/Settings_Monochromatic.png" class="img-fluid d-block" id="webillustration2" alt="Maintenance">
                          </div>
                        </div>
                  </div>


                  <div class="row">
                    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 services md-mt-4 text-start">
                      <div class="services__pic">
                      <img src="/images/Services/SEO_Monochromatic.png" class="img-fluid d-block" alt="SEO">
                      </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 services md-mt-4">
                      <div class="services__contents">
                        <div class="icon"><i class="fa-solid fa-magnifying-glass"></i></div>
                        <h3 class="display-3 mt-1 servicesheading " style="color: navy;">Search Engine Optimization (SEO)</h3>
                        <p class="lh-lg desc" style="font-family: sans-serif; text-align:justify;font-weight: 600;">
                         <b> SEO is known as search engine optimization which makes a website stand out from other websites that 
                          provide the same service or sell the same commodity. Different strategies make websites come up on the list of search engines like google, Bing, Safari,
                           etc. to make a better SEO, marketing skills and customer mindset should be analyzed to make the correct moves. “Let’s think”.  </b>
                        </p>
                        <img src="/images/Services/SEO_Monochromatic.png" class="displayonlyinmobile img-fluid pb-4"  alt="web development">
                        <a href="services.html">
                          <button type="button" class="rounded-pill btn-services border-primary">Go to Services
                            <span><i class="fas fa-arrow-right"></i></span>
                        </button>
                         </a>
                      </div>
                    </div>
              </div>
                  
                </div>
            </section>
      <!--SERVICES END-->
                <br>
                <br>
      <!--PRICING START-->
            <section id="pricing" class="pricing">
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320"><path fill="#ffffff" fill-opacity="1" d="M0,64L24,69.3C48,75,96,85,144,80C192,75,240,53,288,42.7C336,32,384,32,432,69.3C480,107,528,181,576,208C624,235,672,213,720,170.7C768,128,816,64,864,80C912,96,960,192,1008,245.3C1056,299,1104,309,1152,298.7C1200,288,1248,256,1296,208C1344,160,1392,96,1416,64L1440,32L1440,0L1416,0C1392,0,1344,0,1296,0C1248,0,1200,0,1152,0C1104,0,1056,0,1008,0C960,0,912,0,864,0C816,0,768,0,720,0C672,0,624,0,576,0C528,0,480,0,432,0C384,0,336,0,288,0C240,0,192,0,144,0C96,0,48,0,24,0L0,0Z"></path></svg>
              <div class="container">
                <div class="row text-center text-white ">
                  <h1 class="display-3 fw-bold">Pricing</h1>
                  <div class="heading-line2 mb-3"></div>
                <div class="col-md-4 col-sm-4 col-lg-4" >
                  <div class="cardBox">
                    <div class="card">
                      <h2 class="anicard" id="anicardtext">Websites</h2>
                      <br>
                      <div class="content">
                        
                        <p style="text-align: center;">
                          We have categorized websites into different
                           sections with a basic price tag.</p>
                           <a href="pricing.html">
                            <button type="button" class=" buttonmobile rounded-pill btn-services border-primary ">Go to Pricing
                              <span><i class="fas fa-arrow-right"></i></span>
                          </button>
                           </a>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-md-4 col-sm-4 col-lg-4">
                  <div class="cardBox">
                    <div class="card">
                      <h2 class="anicard " id="anicardtext">Domain and Hosting</h2>
                      <br>
                      <div class="content">
                        <p style="text-align: center;">
                          Domain and hosting charges will vary according 
                          to the domain package and hosting plan you select</p>
                          <a href="pricing.html">
                            <button type="button" class=" buttonmobile rounded-pill btn-services border-primary ">Go to Pricing
                              <span><i class="fas fa-arrow-right"></i></span>
                          </button>
                           </a>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-md-4 col-sm-4 col-lg-4">
                  <div class="cardBox ">
                    <div class="card">
                      <h2 class="anicard gfold " id="anicardtext">Maintenance</h2>
                      <br>
                      <div class="content">
                        
                        <p style="text-align: center;">
                          The maintenance charge will be constant for the website you go with. 
                         </p>
                         <a href="pricing.html">
                          <button type="button" class=" buttonmobile rounded-pill btn-services border-primary ">Go to Pricing
                            <span><i class="fas fa-arrow-right"></i></span>
                        </button>
                         </a>
                      </div>
                      
                    </div>
                  </div>  
                </div>
                </div>
              </div>
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320"><path fill="#ffffff" fill-opacity="1" d="M0,64L24,69.3C48,75,96,85,144,80C192,75,240,53,288,42.7C336,32,384,32,432,69.3C480,107,528,181,576,208C624,235,672,213,720,170.7C768,128,816,64,864,80C912,96,960,192,1008,245.3C1056,299,1104,309,1152,298.7C1200,288,1248,256,1296,208C1344,160,1392,96,1416,64L1440,32L1440,320L1416,320C1392,320,1344,320,1296,320C1248,320,1200,320,1152,320C1104,320,1056,320,1008,320C960,320,912,320,864,320C816,320,768,320,720,320C672,320,624,320,576,320C528,320,480,320,432,320C384,320,336,320,288,320C240,320,192,320,144,320C96,320,48,320,24,320L0,320Z"></path></svg>
            </section>
      <!--PRICING END-->

      <!--FAQ [Frequently asked questions] Start-->

          <section id="faq" class="faq">
            <div class="container">
              <div class="row mt-5 text-center">
                <h1 class="display-3 fw-bold text-uppercase">faq?</h1>
                <div class="heading-line"></div>
                <br>
                <p class="lead">Frequently asked questions.</p>
              </div>
              <!--ACCORDION CONTENT START-->

              <div class="row mt-5">
                <div class="col md-12">

                  <!--ACCORDION START-->
                  <div class="accordion" id="accordionExample">
                    <!--ACCORDION ITEM 1 START-->
                    <div class="accordion-item shadow mb-3" style="margin: 0;">
                      <h2 class="accordion-header" id="headingOne">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                          Why should we trust vaceyra?
                        </button>
                      </h2>
                      <div id="collapseOne" class="accordion-collapse collapse " aria-labelledby="headingOne" data-bs-parent="#accordionExample">
                        <div class="accordion-body">
                          <strong>This is the first item's accordion body.</strong> It is shown by default, until the collapse plugin adds the appropriate classes that we use to style each element. These classes control the overall appearance, as well as the showing and hiding via CSS transitions. You can modify any of this with custom CSS or overriding our default variables. It's also worth noting that just about any HTML can go within the <code>.accordion-body</code>, though the transition does limit overflow.
                        </div>
                      </div>
                    </div>
                    <!--ACCORDION ITEM 1 END-->

                    <!--ACCORDION ITEM 2 START-->
                    <div class="accordion-item shadow mb-3">
                      <h2 class="accordion-header" id="headingTwo">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                        Will our website be responsive accross all devices?
                        </button>
                      </h2>
                      <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#accordionExample">
                        <div class="accordion-body">
                          <strong>This is the second item's accordion body.</strong> It is hidden by default, until the collapse plugin adds the appropriate classes that we use to style each element. These classes control the overall appearance, as well as the showing and hiding via CSS transitions. You can modify any of this with custom CSS or overriding our default variables. It's also worth noting that just about any HTML can go within the <code>.accordion-body</code>, though the transition does limit overflow.
                        </div>
                      </div>
                    </div>
                    <!--ACCORDION ITEM 2 END-->

                    <!--ACCORDION ITEM 3 START-->
                    <div class="accordion-item shadow mb-3">
                      <h2 class="accordion-header" id="headingThree">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                          How long will it take to build a website?
                        </button>
                      </h2>
                      <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree" data-bs-parent="#accordionExample">
                        <div class="accordion-body">
                          <strong>This is the third item's accordion body.</strong> It is hidden by default, until the collapse plugin adds the appropriate classes that we use to style each element. These classes control the overall appearance, as well as the showing and hiding via CSS transitions. You can modify any of this with custom CSS or overriding our default variables. It's also worth noting that just about any HTML can go within the <code>.accordion-body</code>, though the transition does limit overflow.
                        </div>
                      </div>
                    </div>
                    <!--ACCORDION ITEM 3 END-->

                    <!--ACCORDION ITEM 4 START-->
                    <div class="accordion-item shadow mb-3">
                      <h2 class="accordion-header" id="headingFour">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
                          What are the basic features in classic websites?
                        </button>
                      </h2>
                      <div id="collapseFour" class="accordion-collapse collapse" aria-labelledby="headingFour" data-bs-parent="#accordionExample">
                        <div class="accordion-body">
                          <strong>This is the third item's accordion body.</strong> It is hidden by default, until the collapse plugin adds the appropriate classes that we use to style each element. These classes control the overall appearance, as well as the showing and hiding via CSS transitions. You can modify any of this with custom CSS or overriding our default variables. It's also worth noting that just about any HTML can go within the <code>.accordion-body</code>, though the transition does limit overflow.
                        </div>
                      </div>
                    </div>
                    <!--ACCORDION ITEM 4 END-->
                  </div>
                 
                  </div>
                  <!--ACCORDIAN END-->

                </div>
              </div>

              <!--ACCORDION CONTENT START-->
            </div>
          </section>
      <!--FAQ [Frequently asked questions] END-->
            <br>
            
      <!--CONTACT START-->
        <section id="contact" class="get-started">


          <div class="container">
            <div class="row text-center">
              <h1 class="display-3 fw-bold text-capitalize">Get Started</h1>
              <div class="heading-line"></div>
                <p class="lh-sm text-center">
                  Submit your contact information, our team will reach out.
                </p>
              </div>
              <!--START THE CTA CONTENT-->
              <div class="row text-white">
                <div class="col-12 col-lg-6 gradient shadow p-3">
                  <div class="cta-info w-100">
                    <h4 class="display-3 fw-bold">We are responsible for your data!</h4>
                    <p class="lh-lg" style="text-align: justify;">
                      The data we collect from you is 100% secured and we assure you that we will use this data only for communication purpose.
                    </p>
                    <hr>
                        <br>
                        <a target="_blank" id="mailtovaceyra" class="rounded-pill btn-rounded mt-2 mb-2 contactemail " href="mailto:info.vaceyra@gmail.com"> Gmail <span ><i style="margin-left: 11.5px;" class="fa-regular fa-envelope"></i></span></a> 
                        <br>
                        
                       <!-- <p class="lh-sm" style="text-align: justify;">
                          If you have any concerns or inquiries you can write us at info.vaceyra@gmail.com by clicking on the button above.
                        </p>-->
                        <br>
                       <br>
                        <a target="_blank" id="mailtovaceyra" class="rounded-pill btn-rounded mt-2 mb-2 contactemail justify-content-end " href="https://api.whatsapp.com/send?phone=94776339744&text=Hi,%20Vaceyra"> Whatsapp <span ><i style="margin-left: 12px;" class="fa-brands fa-whatsapp"></i></span></a>
                        <br>
                        <br>
                        <hr>
                        <p class="lh-sm" style="text-align: justify;">
                          If you have any concerns or inquiries you can write us at info.vaceyra@gmail.com by clicking on the button above.
                          <br><span style="margin-top: 3px;">
                            <br>
                            OR
                            <br>
                          </span>
                          <br>
                          You can have one-to-one conversation by clicking on the WhatsApp button above.
                        </p>
                      </div>
                </div>
              <div class="col-12 col-lg-6 bg-white shadow p-3">
                <div class="form w-100 pb-2">
                  <h3  class="display-3 --title md-mb-5 md-mb-5 mb-3 ">Contact information</h3>
                  <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" class="row" method="post">
                  <div class="col-lg-6 mb-3">
                    <input type="text" placeholder="First Name" id="inputFirstName" name="inputFirstName" class="shadow form-control form-control-lg" required value="<?php echo htmlspecialchars($_POST['inputFirstName'] ?? '', ENT_QUOTES); ?>">
                  </div>  
                  <div class="col-lg-6 mb-3">
                    <input type="text" placeholder="Last Name" id="inputLastName" name="inputLastName" class="shadow form-control form-control-lg" required value="<?php echo htmlspecialchars($_POST['inputLastName'] ?? '', ENT_QUOTES); ?>">
                  </div>
                  <div class="col-lg-12 mb-3">
                    <input type="email" placeholder="Email address" id="inputEmail" name="inputEmail" class="shadow form-control form-control-lg" required value="<?php echo htmlspecialchars($_POST['inputEmail'] ?? '', ENT_QUOTES); ?>">
                  </div>
                  <div class="col-lg-12 mb-3">
                    <textarea name="message" placeholder="Message" id="message" name="message" rows="8" class="shadow form-control form-control-lg" required ><?php echo htmlspecialchars($_POST['message'] ?? '', ENT_QUOTES); ?></textarea>
                  </div>
                  <div class="col-5  mb-3">
                      <input type="text" placeholder="Country code" id="countryCode" name="countryCode" class="shadow form-control form-control-lg" required value="<?php echo htmlspecialchars($_POST['countryCode'] ?? '', ENT_QUOTES); ?>">
                  </div>
                  <div class="col-7 mb-3">
                    <input type="text" id="UserMobile" maxlength="18" data-fv-numeric="true"  required  placeholder="Mobile No. " class="shadow form-control form-control-lg" name="mobilenumber" data-fv-field="mobilenumber" value="<?php echo htmlspecialchars($_POST['mobilenumber'] ?? '', ENT_QUOTES); ?>">
                  </div>
                  <div class="text-center d-grid mt-1">
                  <div id="err" class="form-text " style="color:red;"><?php if(isset($spcerr)) echo $spcerr ; ?></div>
                    <button type="submit" class="btn btn-primary rounded-pill pt-3 pb-3">
                      Submit
                      <i class="fas fa-paper-plane"></i>
                    </button>
                  
                  </div>
                  </form>
                </div>
              </div>
            </div>
              <!--END THE CTA CONTECT-->
            </div>
        </section>    
      <!--CONTACT END-->    

      <!--START FOOTER-->
        
        <footer class="footer">
          <div class="container">
           <div class="row">
            <div class=" col-md-4 col-lg-4 contact-box pt-1   d-md-block d-lg-flex d-flex mb-2">
              <div class="contact-box__icon">
                <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-mail-opened"  viewBox="0 0 24 24" stroke-width="1.1"  fill="none" stroke-linecap="round" stroke-linejoin="round">
                  <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                  <polyline points="3 9 12 15 21 9 12 3 3 9" />
                  <path d="M21 9v10a2 2 0 0 1 -2 2h-14a2 2 0 0 1 -2 -2v-10" />
                  <line x1="3" y1="19" x2="9" y2="13" />
                  <line x1="15" y1="13" x2="21" y2="19" />
                </svg>
              </div>
              <div class="contact-box__info ">
                <a href="mailto:info.vaceyra@gmail.com" class="contact-box__info--title footer-headings">info.vaceyra@gmail.com</a>
                <p class="contact-box__info--subtitle footer-subtitle">Online Support</p>
              </div>
            </div>
            <div class=" col-md-4 col-lg-4 contact-box pt-1  d-md-block d-lg-flex d-flex mb-2 location">
              <div class="contact-box__icon ">
                <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-phone-call"  viewBox="0 0 24 24" stroke-width="1.5" stroke="#eb0202" fill="none" stroke-linecap="round" stroke-linejoin="round">
                  <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                  <path d="M5 4h4l2 5l-2.5 1.5a11 11 0 0 0 5 5l1.5 -2.5l5 2v4a2 2 0 0 1 -2 2a16 16 0 0 1 -15 -15a2 2 0 0 1 2 -2" />
                  <path d="M15 7a2 2 0 0 1 2 2" />
                  <path d="M15 3a6 6 0 0 1 6 6" />
                </svg>
              </div>
              <div class="contact-box__info">
                
                <div class="contact-box__info--title footer-headings">+94 (75)8553557</div>
                <p class="contact-box__info--subtitle footer-subtitle" >Hotline</p>
              </div>
            </div>
            <div class=" col-md-4 col-lg-4 contact-box pt-1 d-md-block d-lg-flex d-flex mb-2 location">
              <div class="contact-box__icon">
                <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler" viewBox="0 0 24 24" stroke-width="1"  fill="none" stroke-linecap="round" stroke-linejoin="round">
                  <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                  <path d="M21 3l-6.5 18a0.55 .55 0 0 1 -1 0l-3.5 -7l-7 -3.5a0.55 .55 0 0 1 0 -1l18 -6.5" />
                </svg>
              </div>
              <div class="contact-box__info">
                <a target="_blank" href="https://goo.gl/maps/SJKDXp87DTRGpdjA7" class="contact-box__info--title footer-headings">Sri Lanka</a>
                <p class="contact-box__info--subtitle footer-subtitle">Colombo</p>
              </div>
            </div>
           </div>
          </div>

          <!--START SOCIAL MEDIA CONTENT-->
          <div class="footer-sm" style="background-color: #212121;">
            <div class="container">
              <div class="row py-4 text-center text-white text-center">
                <div class="col-lg-5 col-md-6 mb-4 col-md-0 col-sm-12">
                  connect with us on social media 
                </div>
                <div class="col-lg-7 col-md-6 col-sm-12 align-items-center">
                 <!--<a target="_blank" href=""><i class="fab fa-facebook"></i></a>-->
                 <a target="_blank" href="https://twitter.com/Vaceyra1?t=OmCRKxEdSWzE9a_AyWV-DA&s=09"><i class="fab fa-twitter"></i></a>
                 <a target="_blank" href="https://www.linkedin.com/in/vaceyra-community-b88486247"><i class="fab fa-linkedin"></i></a>
                 <a target="_blank" href="https://instagram.com/vaceyra?igshid=YmMyMTA2M2Y="><i class="fab fa-instagram"></i></a>
                </div>
              </div>
            </div>
          </div>

          

          <div class="footer-bottom pt-5 pb-5">
            <div class="container">
              <div class="row text-center text-white">
                <div class="col-12">
                  <div class="footer-bottom__copyright">
                    &COPY; Copyright 2022 <a href="https://vaceyra.com/">Vaceyra</a> | Created by <a href="https://vaceyra.com/" >vaceyra.com</a>
                  </div>
                </div>
              </div>
            </div>
          </div>
      </footer>

      <!--END FOOTER-->
       
      <script src="/assets/vendors/js/glightbox.min.js"></script>
    <script src="/assets/JS/bootstrap.bundle.js"></script>
</body>
</html>